package com.example.servicemonitor.domain;

public enum UserRole {
    ADMIN,
    USER
}
