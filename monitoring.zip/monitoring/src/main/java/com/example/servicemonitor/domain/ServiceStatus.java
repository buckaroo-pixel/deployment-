package com.example.servicemonitor.domain;

public enum ServiceStatus {
    UP,
    DOWN,
    UNKNOWN
}
